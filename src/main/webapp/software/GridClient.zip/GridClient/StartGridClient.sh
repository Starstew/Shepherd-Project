#! /bin/sh
# cd <your_path_to_the_client_here>
# java -classpath .:javax.jdo-3.2.0-m3.jar:weka-dev-3.7.13.jar;commons-math3-3.2.jar:fastdtw-0.1.jar:datanucleus-api-jdo-4.2.0-release.jar:datanucleus-core-4.1.7.jar -Xms256m -Xmx8192m org.ecocean.grid.WorkAppletHeadlessEpic www.flukebook.org
